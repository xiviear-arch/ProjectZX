package com.example.archiver

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    private fun Screen() {
        val scope = rememberCoroutineScope()
        var status by remember { mutableStateOf("Pick an action to start.") }
        var busy by remember { mutableStateOf(false) }
        var pendingArchive by remember { mutableStateOf<Uri?>(null) }
        var pendingSources by remember { mutableStateOf<List<Uri>>(emptyList()) }

        fun run(label: String, work: suspend () -> String) {
            scope.launch {
                busy = true
                status = "$label…"
                status = try {
                    withContext(Dispatchers.IO) { work() }
                } catch (e: Exception) {
                    "Error: ${e.message}"
                }
                busy = false
            }
        }

        val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
            val archive = pendingArchive
            if (tree != null && archive != null) run("Extracting") {
                val n = ArchiveEngine.extract(this@MainActivity, archive, tree) { f -> status = "Extracting: $f" }
                "Done. Extracted $n files."
            }
        }
        val pickArchive = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) { pendingArchive = uri; pickFolder.launch(null) }
        }
        val saveZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { dest ->
            if (dest != null && pendingSources.isNotEmpty()) run("Compressing") {
                val n = ArchiveEngine.createZip(this@MainActivity, pendingSources, dest) { f -> status = "Adding: $f" }
                "Done. Added $n files."
            }
        }
        val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) { pendingSources = uris; saveZip.launch("archive.zip") }
        }

        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.padding(24.dp).statusBarsPadding().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("ProjectZX", style = MaterialTheme.typography.headlineMedium)
                Text("Extract ZIP, 7z, RAR, TAR, TAR.GZ, TAR.XZ. Create ZIP.")
                Button(onClick = { pickArchive.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Extract archive")
                }
                Button(onClick = { pickFiles.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Create ZIP from files")
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(status)
            }
        }
    }
}
