package com.example.archiver

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.github.junrar.Archive
import org.apache.commons.compress.archivers.ArchiveEntry
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ArchiveEngine {

    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "file"
    }

    /** Extracts [archive] into a new folder inside [destTree]. Returns number of files written. */
    fun extract(ctx: Context, archive: Uri, destTree: Uri, onProgress: (String) -> Unit): Int {
        val name = displayName(ctx, archive)
        val lower = name.lowercase()
        val base = name.substringBeforeLast('.').removeSuffix(".tar")
        val tree = DocumentFile.fromTreeUri(ctx, destTree) ?: error("Cannot open destination")
        val root = tree.createDirectory(base) ?: error("Cannot create output folder")

        fun input(): InputStream =
            BufferedInputStream(ctx.contentResolver.openInputStream(archive) ?: error("Cannot open archive"))

        return when {
            lower.endsWith(".zip") || lower.endsWith(".jar") || lower.endsWith(".apk") ->
                input().use { readStream(ctx, ZipArchiveInputStream(it), root, onProgress) }
            lower.endsWith(".tar") ->
                input().use { readStream(ctx, TarArchiveInputStream(it), root, onProgress) }
            lower.endsWith(".tar.gz") || lower.endsWith(".tgz") ->
                input().use { readStream(ctx, TarArchiveInputStream(GzipCompressorInputStream(it)), root, onProgress) }
            lower.endsWith(".tar.xz") || lower.endsWith(".txz") ->
                input().use { readStream(ctx, TarArchiveInputStream(XZCompressorInputStream(it)), root, onProgress) }
            lower.endsWith(".7z") -> withCacheCopy(ctx, archive) { sevenZ(ctx, it, root, onProgress) }
            lower.endsWith(".rar") -> withCacheCopy(ctx, archive) { rar(ctx, it, root, onProgress) }
            else -> error("Unsupported format: $name")
        }
    }

    private fun readStream(
        ctx: Context, ais: ArchiveInputStream<out ArchiveEntry>, root: DocumentFile, onProgress: (String) -> Unit
    ): Int {
        var count = 0
        ais.use {
            while (true) {
                val e = it.nextEntry ?: break
                if (e.isDirectory) ensureDir(root, e.name) else {
                    writeEntry(ctx, root, e.name) { out -> it.copyTo(out) }
                    count++
                }
                onProgress(e.name)
            }
        }
        return count
    }

    private fun sevenZ(ctx: Context, file: File, root: DocumentFile, onProgress: (String) -> Unit): Int {
        var count = 0
        SevenZFile(file).use { sz ->
            var e = sz.nextEntry
            while (e != null) {
                if (e.isDirectory) ensureDir(root, e.name) else {
                    writeEntry(ctx, root, e.name) { out ->
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val n = sz.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                        }
                    }
                    count++
                }
                onProgress(e.name)
                e = sz.nextEntry
            }
        }
        return count
    }

    private fun rar(ctx: Context, file: File, root: DocumentFile, onProgress: (String) -> Unit): Int {
        var count = 0
        Archive(file).use { a ->
            var h = a.nextFileHeader()
            while (h != null) {
                val path = h.fileName.replace('\\', '/')
                if (h.isDirectory) ensureDir(root, path) else {
                    writeEntry(ctx, root, path) { out -> a.extractFile(h, out) }
                    count++
                }
                onProgress(path)
                h = a.nextFileHeader()
            }
        }
        return count
    }

    private fun <T> withCacheCopy(ctx: Context, uri: Uri, block: (File) -> T): T {
        val tmp = File.createTempFile("arc", ".tmp", ctx.cacheDir)
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            return block(tmp)
        } finally {
            tmp.delete()
        }
    }

    // ---- SAF helpers (with zip-slip protection) ----

    private fun safeParts(path: String): List<String> {
        val parts = path.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
        require(parts.none { it == ".." }) { "Blocked unsafe path: $path" }
        return parts
    }

    private fun ensureDir(root: DocumentFile, path: String): DocumentFile {
        var dir = root
        for (p in safeParts(path)) {
            dir = dir.findFile(p)?.takeIf { it.isDirectory } ?: dir.createDirectory(p) ?: error("mkdir failed: $p")
        }
        return dir
    }

    private fun writeEntry(ctx: Context, root: DocumentFile, path: String, write: (OutputStream) -> Unit) {
        val parts = safeParts(path)
        if (parts.isEmpty()) return
        val dir = if (parts.size > 1) ensureDir(root, parts.dropLast(1).joinToString("/")) else root
        val file = dir.createFile("application/octet-stream", parts.last()) ?: error("create failed: $path")
        ctx.contentResolver.openOutputStream(file.uri)!!.use(write)
    }

    // ---- Create ZIP ----

    fun createZip(ctx: Context, sources: List<Uri>, dest: Uri, onProgress: (String) -> Unit): Int {
        var count = 0
        val used = HashSet<String>()
        ZipOutputStream(ctx.contentResolver.openOutputStream(dest)!!.buffered()).use { zos ->
            for (uri in sources) {
                var name = displayName(ctx, uri)
                var n = 1
                while (!used.add(name)) name = "${n++}_" + displayName(ctx, uri)
                zos.putNextEntry(ZipEntry(name))
                ctx.contentResolver.openInputStream(uri)!!.use { it.copyTo(zos) }
                zos.closeEntry()
                onProgress(name)
                count++
            }
        }
        return count
    }
}
